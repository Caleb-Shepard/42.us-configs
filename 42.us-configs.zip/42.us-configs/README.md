# 42.us-configs
dotfiles for 42.us
