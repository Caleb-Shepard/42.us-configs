source "${0:h}/z.sh"
